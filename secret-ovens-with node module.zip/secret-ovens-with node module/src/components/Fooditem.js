import React from "react";
import "../styles/fooditems.css"
function Fooditem(){

    const items=[
        {
            title: "Cheese & Tomato Pizza",
            price: 379,
            image: "../img/cheese_and_tomato.png",
        },
        {
            title:"Creamy Tomato Pasta Pizza",
            price: 459,
            image: "../img/CreamyTomatoPPVG.jpg",
        },
        {
            title: "Double Cheese Margherita Pizza",
            price: 379,
            image: "../img/double_cheese_margherita_2502.png",
        },
    ]

    return(
        <>
        <div className="container">
        <div style={{display: "flex"}}>
            <table>
          {items.map((res)=>     
        <div className="row">
            <tr>
              <td><img className="shop-item-image" src={res.image} alt="pizza"></img></td>
              <td className="shop-item-title">{res.title}</td>
              <td><span className="shop-item-price">Rs.{res.price}</span></td>
              <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
            </tr>
            </div>
        )}
            </table>
            </div>
            </div>
        </>
    )
}

export default Fooditem