import React from "react";

function Header(){
    return(
    <div>
        <nav class="navbar">
        <header>
            Secret Ovens
        </header>
        <ul id="navcontent">
            <li class="nav-item"><a href="#">Home</a></li>
            <li class="nav-item"><a href="#">About Us</a></li>
            <li class="nav-item"><a href="#">Popular</a></li>
            <li class="nav-item"><a href="#">Recently</a></li>
        </ul>
    </nav>
    </div>)
}

export default Header