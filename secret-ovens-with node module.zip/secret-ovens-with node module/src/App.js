import './App.css';
import Header from './components/Header';
import Food from './components/Food';
import Fooditem from './components/Fooditem';
import Cart from './components/Cart';
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
      <Header></Header>
      <Fooditem></Fooditem>
      <Footer></Footer>
    </div>
  );
}

export default App;
