import React from 'react'
import "../styles/Cart.css"

export default function Cart() {
  return (
  <>
     <div class="wrapper">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex flex-column">
                <div class="h3">My lists</div>
            </div>
        </div>

        <div id="table" class="bg-white rounded">
               
                    
            <hr/>
            <div class="table-responsive">
                <table class="table activitites">
                    <thead>
                        <tr>
                            <th scope="col" class="text-uppercase header">item</th>
                            <th scope="col" class="text-uppercase">Quantity</th>
                            <th scope="col" class="text-uppercase">price each</th>
                            <th scope="col" class="text-uppercase">total</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    <tr>
                            <td class="item">
                                <div class="d-flex align-items-start">
                                    <img src="https://www.freepnglogos.com/uploads/corona-png-logo/corona-bottle-transparent-png-logo-27.png"
                                        alt="" />
                                    <div>
                                        Wine Bottle Shaped in Gift Base
                                    </div>
                                </div>
                            </td>
                            <td>120</td>
                            <td class="d-flex flex-column">$21.40
                            </td>
                            <td class="font-weight-bold">
                                $249
                                <div class="close">&times;</div>
                                <button class="d-flex justify-content-end align-items-end btn border">+ Add to
                                    cart</button>
                            </td>
                        </tr>


                    </tbody>
                </table>
            </div>
            <hr class="items"/>

        </div>
        <div class="d-flex justify-content-between">
            {/* <div class="text-muted">
                <button class="btn" type="button" data-toggle="collapse" data-target="#table" aria-expanded="false"
                    aria-controls="table">
                    Hide
                    <span class="fas fa-minus"></span>
                </button>
            </div> */}
            <div class="d-flex flex-column justify-content-end align-items-end">
                <div class="d-flex px-3 pr-md-5 py-1 subtotal">
                    <div class="px-4">Subtotal</div>
                    <div class="h5 font-weight-bold px-md-2">$1,340</div>
                </div>
            </div>
        </div>
    </div>
    
    </>
  )
}
