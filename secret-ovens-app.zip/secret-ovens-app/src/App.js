import './App.css';
import Header from './components/Header';
import Food from './components/Food';
import Fooditem from './components/Fooditem';
import Cart from './components/Cart';

function App() {
  return (
    <div className="App">
      <Header></Header>
      {/* <Fooditem></Fooditem> */}
    </div>
  );
}

export default App;
