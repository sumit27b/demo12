import React from "react";

function Food(){

}

export default Food