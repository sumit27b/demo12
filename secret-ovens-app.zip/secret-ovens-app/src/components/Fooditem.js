import React from "react";

function Fooditem(){
    return(
        <div>
            <section>
            <h2 className="section-header" style="text-align:center;">SHOP</h2>
            <div style="display: flex;">
            <table>
                <tr>
                    <td className="shop-item-title">Cheese & Tomato Pizza</td>
                    <td><img className="shop-item-image" src="./img/cheese_and_tomato.png"/></td>
                    <td><span className="shop-item-price">Rs.379</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Creamy Tomato Pasta Pizza</td>
                    <td><img className="shop-item-image" src="./img/CreamyTomatoPPVG.jpg"/></td>
                    <td><span className="shop-item-price">Rs.459</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Double Cheese Margherita Pizza</td>
                    <td><img className="shop-item-image" src="./img/double_cheese_margherita_2502.png"/></td>
                    <td><span className="shop-item-price">Rs.379</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Deluxe Veggie Pizza</td>
                    <td><img className="shop-item-image" src="./img/new_deluxe_veggie.png"/></td>
                    <td><span className="shop-item-price">Rs.549</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Indian Tandoori Paneer Pizza</td>
                    <td><img className="shop-item-image" src="./img/IndianTandooriPaneer.png"/></td>
                    <td><span className="shop-item-price">Rs.549</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Fresh Veggie Pizza</td>
                    <td><img className="shop-item-image" src="./img/new_fresh_veggie.png"/></td>
                    <td><span className="shop-item-price">Rs.399</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>    
                <tr>
                    <td className="shop-item-title">Margherita Pizza</td>
                    <td><img className="shop-item-image" src="./img/new_margherita_2502.png"/></td>
                    <td><span className="shop-item-price">Rs.239</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Mexican Green Wave Pizza</td>
                    <td><img className="shop-item-image" src="./img/new_mexican_green_wave.png"/></td>
                    <td><span className="shop-item-price">Rs.459</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Veggie Paradise Pizza</td>
                    <td><img className="shop-item-image" src="./img/new_veggie_paradise.png"/></td>
                    <td><span className="shop-item-price">Rs.459</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Paneer Makhani Pizza</td>
                    <td><img className="shop-item-image" src="./img/updated_paneer_makhani.png"/></td>
                    <td><span className="shop-item-price">Rs.549</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Pepper Barbeque Chicken Pizza</td>
                    <td><img className="shop-item-image" src="./img/new_pepper_barbeque_chicken.png"/></td>
                    <td><span className="shop-item-price">Rs.449</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
                <tr>
                    <td className="shop-item-title">Chicken Sausage Pizza</td>
                    <td><img className="shop-item-image" src="./img/new_chicken_sausage.png"/></td>
                    <td><span className="shop-item-price">Rs.369</span></td>
                    <td><button className="btn btn-primary shop-item-button" type="button">ADD TO CART</button></td>
                </tr>
            </table>
          </div>
        </section>
        <footer>Copyright © 2023-2024 FoodyMoody.
        All Rights are reserved</footer>
    </div>
    )
}

export default Fooditem