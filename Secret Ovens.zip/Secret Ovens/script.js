function ready() {

  var addToCartButtons = document.getElementsByClassName('shop-item-button')
  //use foreach
  for (var i = 0; i < addToCartButtons.length; i++) {
      var button = addToCartButtons[i]
      button.addEventListener('click', addToCartClicked)
  }

  document.getElementsByClassName('btn-purchase')[0].addEventListener('click', purchaseClicked)
}


function addToCartClicked(event) {
  var button = event.target
  var shopItem = button.parentElement.parentElement
  var title = shopItem.getElementsByClassName('shop-item-title')[0].innerText
  var price = shopItem.getElementsByClassName('shop-item-price')[0].innerText
  var imageSrc = shopItem.getElementsByClassName('shop-item-image')[0].src
  addItemToCart(title, price, imageSrc)
  updateCartTotal()
}

function purchaseClicked() {
  alert('Thank you for your purchase')
  var cartItems = document.getElementsByClassName('cart-items')[0]
  //Use foreach
  while (cartItems.hasChildNodes()) {
      cartItems.removeChild(cartItems.firstChild)
  }
  updateCartTotal()
}


















// function addItemToCart(title, price, imageSrc) {
//   var cartRow = document.createElement('div')
//   cartRow.classList.add('cart-row')
//   var cartItems = document.getElementsByClassName('cart-items')[0]
//   var cartItemNames = cartItems.getElementsByClassName('cart-item-title')
//   for (var i = 0; i < cartItemNames.length; i++) {
//       if (cartItemNames[i].innerText == title) {
//           alert('This item is already added to the cart')
//           return
//       }
//   }
  // var cartRowContents = `
  //     <div class="cart-item cart-column">
  //         <img class="cart-item-image" src="${imageSrc}" width="100" height="100">
  //         <span class="cart-item-title">${title}</span>
  //     </div>
  //     <span class="cart-price cart-column">${price}</span>
  //     <div class="cart-quantity cart-column">
  //         <input class="cart-quantity-input" type="number" value="1">
  //         <button class="btn btn-danger" type="button">REMOVE</button>
  //     </div>`
  // cartRow.innerHTML = cartRowContents
  // cartItems.append(cartRow)
  // cartRow.getElementsByClassName('btn-danger')[0].addEventListener('click', removeCartItem)
  // cartRow.getElementsByClassName('cart-quantity-input')[0].addEventListener('change', quantityChanged)
// }





















































// const menu_container = document.getElementById('menu');
// const order_tbl = document.getElementById('order-tbl');
// const menu = [
//   {
//     name: "Veg Overload Pizza",
//     price: 250
//   },
//   {
//     name: "Chicken Overload Pizza",
//     price: 300
//   },
//   {
//     name: "Veg Marghrita Pizza",
//     price: 220
//   },
//   {
//     name: "Pepperoni Pizza",
//     price: 349
//   },
//   {
//     name: "Cheese Overload Pizza",
//     price: 320
//   },
//   {
//     name: "Caprese Gourmet Pizza",
//     price: 659
//   },
//   {
//     name: "The 5 Cheese Gourmet Pizza",
//     price: 699
//   },
//   {
//     name: "Corn n Cheese Paratha Pizza",
//     price: 250
//   },
//   {
//     name: "Peppy Paneer pizza",
//     price: 390
//   },
//   {
//     name: "Pepper Barbecue Chicken",
//     price: 420
//   }
// ];

// function initApp() {
//     for (let i = 0; i < menu.length; i++) {
//       let str = '<div class="menu-item">';
//       str += '<p class="food-name">' + menu[i].name + '</p>';
//       str += '<p class="price">' + (menu[i].price == 0 ? 'Free' : menu[i].price + 'k') + '</p>';
//       str += '<input class="qty" type="number" name="qty" value="1" min="1" max="100" >';
//       str += '<button class="add-btn" type="button" value="' + i + '" onclick="addItem(' + i +')">ADD</button>';
//       str += '</div>';
//       menu_container.insertAdjacentHTML('beforeend', str);
//     }
//     updateOrderList();
//   }
  
//   initApp();