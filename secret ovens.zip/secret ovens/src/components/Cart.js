import React, { useEffect, useState } from 'react'
import "../styles/Cart.css"

export default function Cart() {

    const [arr,setArr]=useState(JSON.parse(localStorage.getItem("data")));
    const [total,setTotal]=useState('0');


    useEffect(()=>{
        onLoad();
    },[])

    const onLoad=()=>{
        let sum=0;
        let objArr=[];
        arr.forEach((ele)=>{
                let obj={
                    title:ele.title,
                    price:ele.price,
                    quantity:1,
                    image:ele.image,
                }
                objArr.push(obj);
                sum+=ele.price*1;
            })
        setArr(objArr);
        setTotal(sum);
    }

    const setQuantity=(res,e)=>{
        let objArr=[];
        let sum=0;
        arr.forEach((ele)=>{
            if(ele.title===res.title){
            let obj={
                title:ele.title,
                price:ele.price,
                quantity:e,
                image:ele.image,
            }
            objArr.push(obj);
            sum+=ele.price*e;    
        }
            else{
                let obj={
                    title:ele.title,
                    price:ele.price,
                    quantity:ele.quantity,
                    image:ele.image,
                }
            objArr.push(obj);
            sum+=ele.price*ele.quantity;
            }
        })
        setTotal(sum);
        setArr(objArr);
    }


  return (
  <>
     <div className="wrapper">
        <div className="d-flex align-items-center justify-content-between">
            <div className="d-flex flex-column">
                <div className="h3">My lists</div>
            </div>
        </div>

        <div id="table" className="bg-white rounded">
               
                    
            <hr/>
            <div className="table-responsive">
                <table className="table activitites">
                    <thead>
                        <tr>
                            <th scope="col" className="text-uppercase header">item</th>
                            <th scope="col" className="text-uppercase">Quantity</th>
                            <th scope="col" className="text-uppercase">price each</th>
                            {/* <th scope="col" className="text-uppercase">total</th> */}
                        </tr>
                    </thead>
                    <tbody>

                    {arr.map((res)=>
                    <tr>
                            <td className="item">
                                <div className="d-flex align-items-start">
                                    <div>
                                       {res.title}
                                    </div>
                                </div>
                            </td>
                            <td><input className='cart-quantity-input' defaultValue={1} type="number" onChange={e=>setQuantity(res,e.target.value)} min={1} ></input></td>
                            <td className="d-flex flex-column">Rs.{res.price}
                            </td>
                            <td class="font-weight-bold">
                                <button className="d-flex justify-content-end btn btn-danger btn border">remove</button>
                            </td>
                            {/* <td className="font-weight-bold">
                                <div className="close">&times;</div>
                            </td> */}
                        </tr>
)}


                    </tbody>
                </table>
            </div>
            <hr className="items"/>

        </div>
        <div className="d-flex justify-content-between">
           
            <div className="d-flex flex-column justify-content-end align-items-end">
                
                <div className="subtotal">
                    <div className="px-4">Total</div>
                    <div className="h5 font-weight-bold px-md-2">Rs.{total}</div>
                </div>
            </div>
        </div>
    </div>
    
    </>
  )
}
