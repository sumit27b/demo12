import React, { useEffect, useState } from "react";
import "../styles/Cart.css";
import swal from "sweetalert";
import { useNavigate } from "react-router-dom";

export default function Cart() {
    const [arr, setArr] = useState(JSON.parse(localStorage.getItem("data")));
    const [total, setTotal] = useState("0");
    const navigate = useNavigate();

    useEffect(() => {
        onLoad();
    }, []);

    const alert = () => {
        swal("Thank You...", "Your Order Is Placed Successfully.", "success");
        setTimeout(() => {
            navigate('/');
            
        }, 3000);
    };

    const removeFromCart=(res)=>{
        console.log(res);
        let objArr = [];
        let sum = 0;
        arr.forEach((ele) => {
            if(ele.title!==res.title){
                objArr.push(ele);
                sum += ele.price * ele.quantity;
            }
        });
        setTotal(sum);
        localStorage.removeItem("data");
        localStorage.setItem("data",JSON.stringify(objArr));
        setArr(JSON.parse(localStorage.getItem("data")));
        console.log("removed from cart");
        // console.log(total);
    }

    const onLoad = () => {
        let sum = 0;
        arr.forEach((ele) => {
            sum += ele.price * ele.quantity;
        });
        setTotal(sum);
    };

    const setQuantity = (res, e) => {
        let objArr = [];
        let sum = 0;
        arr.forEach((ele) => {
            if (ele.title === res.title) {
                let obj = {
                    title: ele.title,
                    price: ele.price,
                    quantity: e,
                    image: ele.image,
                };
                objArr.push(obj);
                sum += ele.price * e;
            } else {
                let obj = {
                    title: ele.title,
                    price: ele.price,
                    quantity: ele.quantity,
                    image: ele.image,
                };
                objArr.push(obj);
                sum += ele.price * ele.quantity;
            }
        });
        localStorage.removeItem("data");
        localStorage.setItem("data",JSON.stringify(objArr));
        setArr(JSON.parse(localStorage.getItem("data")));
        setTotal(sum);
    };
    

    return (
        <>
            <div className="wrapper">
                <div className="d-flex align-items-center justify-content-between">
                    <div className="d-flex flex-column">
                        <div className="h3">My lists</div>
                    </div>
                </div>

                <div id="table" className="bg-white rounded">
                    <hr />
                    <div className="table-responsive">
                        <table className="table activitites">
                            <thead>
                                <tr>
                                    <th scope="col" className="text-uppercase header">
                                        item
                                    </th>
                                    <th scope="col" className="text-uppercase">
                                        Quantity
                                    </th>
                                    <th scope="col" className="text-uppercase">
                                        price each
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                {arr.map((res) => (
                                    <tr>
                                        <td className="item">
                                            <div className="d-flex align-items-start">
                                                <div>{res.title}</div>
                                            </div>
                                        </td>
                                        <td>
                                            <input
                                                className="cart-quantity-input"
                                                type="number"
                                                onChange={(e) => setQuantity(res, e.target.value)}
                                                value={res.quantity}
                                                min={1}
                                            ></input>
                                        </td>
                                        <td className="d-flex flex-column">Rs.{res.price}</td>
                                        <td className="font-weight-bold">
                                            <button className="d-flex justify-content-end btn btn-danger " onClick={e=>removeFromCart(res)} >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                                    <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                                </svg>
                                            </button>
                                        </td>
                                        {/* <td className="font-weight-bold">
                                <div className="close">&times;</div>
                            </td> */}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <hr className="items" />
                </div>
                <div className="d-flex justify-content-between">
                    <div className="d-flex flex-column justify-content-end align-items-end">
                        <div className="subtotal">
                            <div className="px-4">Total</div>
                            <div className="h5 font-weight-bold px-md-2">Rs.{total}</div>
                        </div>
                    </div>
                    <button
                        onClick={alert}
                        className="d-flex justify-content-end btn btn-danger btn border"
                    >
                        Purchase
                    </button>
                </div>
            </div>
        </>
    );
}
