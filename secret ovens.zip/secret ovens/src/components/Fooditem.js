import React from "react";
import "../styles/fooditems.css"
import pizza1 from "../img/cheese_and_tomato.png";
import pizza2 from "../img/CreamyTomatoPPVG.jpg";
import pizza3 from "../img/double_cheese_margherita_2502.png";
function Fooditem(){

    const arr=[];


    const addToCart=(e)=>{

            if(!arr.includes(e)){
                arr.push(e);
                localStorage.removeItem("data");
                localStorage.setItem("data",JSON.stringify(arr));
            }
            else{
                alert("already added in cart");
            }
        console.log(arr);
    }

    const items=[
        {
            title: "Cheese & Tomato Pizza",
            price: 379,
            image: pizza1,
        },
        {
            title:"Creamy Tomato Pasta Pizza",
            price: 459,
            image: pizza2,
        },
        {
            title: "Double Cheese Margherita Pizza",
            price: 379,
            image: pizza3,
        },
    ]

    return(
        <>
        <div className="container">
        <div style={{display: "flex"}}>
            <table>
          {items.map((res)=>     
        <div className="row">
            <tr>
              <td><img className="shop-item-image" src={res.image} alt="pizza"></img></td>
              <td className="shop-item-title">{res.title}</td>
              <td><span className="shop-item-price">Rs.{res.price}</span></td>
              <td><button className="btn btn-primary shop-item-button" onClick={e=>addToCart(res)} type="button">ADD TO CART</button></td>
            </tr>
            </div>
        )}
            </table>
            </div>
            </div>
        </>
    )
}

export default Fooditem