import React from 'react'

export default function Footer() {
  return (
    <>
     <footer>Copyright © 2023-2024 FoodyMoody.
        All Rights are reserved</footer>
    </>
  )
}
