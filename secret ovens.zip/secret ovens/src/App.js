import './App.css';
import { Route, Routes, BrowserRouter } from "react-router-dom";
import Header from './components/Header';
import Fooditem from './components/Fooditem';
import Cart from './components/Cart';
import Footer from './components/Footer';

function App() {
  return (
    <>
      <Header></Header>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Fooditem />}/>
        <Route path="/cart" element={<Cart />}/>
      </Routes>
      </BrowserRouter>
      <Footer></Footer>
    </>
  );
}

export default App;
