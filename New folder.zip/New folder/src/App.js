import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Routes, BrowserRouter } from "react-router-dom";
import Header from './components/Header';
import Fooditem from './components/Fooditem';
import Cart from './components/Cart';
import Footer from './components/Footer';
import SignInSignUp from './components/SignInSignUp';
function App() {
  return (
    <>
      <Header></Header>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<SignInSignUp/>}></Route>
        <Route path="/fooditem" element={<Fooditem />}/>
        <Route path="/cart" element={<Cart />}/>
      </Routes>
      </BrowserRouter>
      <Footer></Footer>
    </>
  );
}

export default App;
