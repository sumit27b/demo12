if (document.readyState == "loading") {
    document.addEventListener("DOMContentLoaded", purchasedItems);
  } else {
    purchasedItems();
  }


function purchasedItems() {
    let item=[];
    item=  JSON.parse(localStorage.getItem("data"));
    console.log(item);
    let cartRow = document.createElement("div");
    let cartItems = document.getElementsByClassName("cart-items")[0];
    cartRow.classList.add("cart-row");
    item.forEach((ele, index, array) => {
      console.log("line 115", ele.title);
      let cartRow1Contents = `
      <div class="cart-row">
          <img class="cart-item-image" src="${ele.imageSrc}" width="120" height="120">
          <span class="cart-item-title">${ele.title}</span>
          <span class="cart-price" style="margin-left:17%;">${ele.price}</span>
          </div>
          `
          cartRow.innerHTML = cartRow1Contents
          cartItems.append(cartRow)
        });
  
  
  
  }
  
  