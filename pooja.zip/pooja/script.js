
const menu_container = document.getElementById('menu');
const order_tbl = document.getElementById('order-tbl');
const menu = [
  {
    name: "Veg Overload Pizza",
    price: 250
  },
  {
    name: "Chicken Overload Pizza",
    price: 300
  },
  {
    name: "Veg Marghrita Pizza",
    price: 220
  },
  {
    name: "Pepperoni Pizza",
    price: 349
  },
  {
    name: "Cheese Overload Pizza",
    price: 320
  },
  {
    name: "Caprese Gourmet Pizza",
    price: 659
  },
  {
    name: "The 5 Cheese Gourmet Pizza",
    price: 699
  },
  {
    name: "Corn n Cheese Paratha Pizza",
    price: 250
  },
  {
    name: "Peppy Paneer pizza",
    price: 390
  },
  {
    name: "Pepper Barbecue Chicken",
    price: 420
  }
];

function initApp() {
    for (let i = 0; i < menu.length; i++) {
      let str = '<div class="menu-item">';
      str += '<p class="food-name">' + menu[i].name + '</p>';
      str += '<p class="price">' + (menu[i].price == 0 ? 'Free' : menu[i].price + 'k') + '</p>';
      str += '<input class="qty" type="number" name="qty" value="1" min="1" max="100" >';
      str += '<button class="add-btn" type="button" value="' + i + '" onclick="addItem(' + i +')">ADD</button>';
      str += '</div>';
      menu_container.insertAdjacentHTML('beforeend', str);
    }
    updateOrderList();
  }
  
  initApp();